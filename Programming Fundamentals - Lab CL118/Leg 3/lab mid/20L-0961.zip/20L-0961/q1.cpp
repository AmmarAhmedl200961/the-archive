#include <iostream>
#include <cmath>
using namespace std;

void print(int a[], int size) {
    for (int i = 0; i < size; i++)
    {
        cout << a[i] << " ";
    }
}

unsigned long long int bintoDec(unsigned long long int bin) {
    int dec = 0, j = 1, rem;
    while (bin != 0)
    {
        rem = bin % 10;
        dec += rem * j;
        j *= 2;
        bin /= 10;
    }

    return dec;
}

unsigned long long int dectoBin(unsigned long long int n) {
    
    int r;
    unsigned long long int binary = 0, i = 1;

    while (n != 0) {
        r = n % 2;
        n /= 2;
        binary += (r * i);
        i *= 10;
    }
    return binary;

}

void modifyArr(int a[], int size, int k) {

    for (int i = 0; i < size; i++)
    {
        if (a[i] < k)
        {
            unsigned long long int bin, bin_k;
            bin = dectoBin(a[i]);
            bin_k = dectoBin(k);

            while (bin < bin_k)
            {
                bin *= 10;
            }

            a[i] = bintoDec(bin);
        }
    }

}


int main() {

	int arr[] = { 21,22,23,19 };
	int arrTemp[4] = { 10101,10110,10111,10011 };
	int k;
	cin >> k;
	modifyArr(arr, 4, k);
    print(arr, 4);

	return 0;
}