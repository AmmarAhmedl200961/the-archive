#include <iostream>  
using namespace std;

int main()
{
	int size;
	cout << "Enter Alphabet" << endl;
	cin >> size;

	// Number of letters in this loop will be from 65-90 (ascii)

	if (size < 26)
	{

		char sp = ' ';

		for (int i = 1; i <= size; i++)
		{
			for (int j = 1; j <= size - i; j++)
			{
				cout << sp;
			}
			for (char out = 'A'; out <= (char)(i + 64); out++)
			{
				cout << out;
			}
			for (char out = (char)(i - 1 + 64); out >= 'A'; out--)
			{
				cout << out;
			}

			cout << endl;
		}
	}

	return 0;
}