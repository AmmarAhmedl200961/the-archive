#include <iostream>
using namespace std;

// Task 1

int main()
{
	int total_bill, amount_paid;
	int bill_5K, bill_1k, bill_500, bill_100, bill_50, bill_20, bill_10, coin_5, coin_2, coin_1;
	int amount = 0;

	cout << "enter bill amount ";
	cin >> total_bill;
	cout << endl << "enter amount paid by customer ";
	cin >> amount_paid;

	amount = amount_paid - total_bill;

	if (amount < 0)
	{
		cout << endl << "amount paid is less than the total bill";
	}
	else
	{
		bill_5K = bill_1k = bill_500 = bill_100 = bill_50 = bill_20 = bill_10 = coin_5 = coin_2 = coin_1 = 0; // initializes all with 0

		if (amount >= 5000)
		{
			bill_5K++;
		}
		if (amount % 1000==0)
		{
			bill_1k++;
		}
		if (amount % 500==0)
		{
			bill_500++;
		}
		if (amount % 100==0)
		{
			bill_100++;
		}
		if (amount % 50==0)
		{
			bill_50++;
		}
		if (amount % 20==0)
		{
			bill_20++;
		}
		if (amount % 10==0)
		{
			bill_10++;
		}
		if (amount % 5==0)
		{
			coin_5++;
		}
		if (amount % 2==0)
		{
			coin_2++;
		}
		if (amount % 1==0)
		{
			coin_1++;
		}
		cout << amount;

		cout << endl << "5000 " << bill_5K;
		cout << endl << "1000 " << bill_1k;
		cout << endl << "500 " << bill_500;
		cout << endl << "100 " << bill_100;
		cout << endl << "50 " << bill_50;
		cout << endl << "20 " << bill_20;
		cout << endl << "10 " << bill_10;
		cout << endl << "5 " << coin_5;
		cout << endl << "2 " << coin_2;
		cout << endl << "1 " << coin_1;




	}


	return 0;
}